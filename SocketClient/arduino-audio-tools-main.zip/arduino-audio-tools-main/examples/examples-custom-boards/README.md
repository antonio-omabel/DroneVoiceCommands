
Some Examples that show how to use some custom boards with their corresponding I2S pins 