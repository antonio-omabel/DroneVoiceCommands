#ifdef IS_DESKTOP 

#include "Arduino.h"
int main(){
  setup();
  while(true) loop();
}

#endif