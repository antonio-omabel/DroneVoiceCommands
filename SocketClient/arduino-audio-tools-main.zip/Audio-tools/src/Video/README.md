
We provide some simple classes that support the playing of videos